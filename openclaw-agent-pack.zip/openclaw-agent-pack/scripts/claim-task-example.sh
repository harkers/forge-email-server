#!/usr/bin/env bash
set -euo pipefail

TASK_ID="${1:-TASK-000123}"
QUEUE_ROOT="${QUEUE_ROOT:-/srv/forgeorchestrate/queue}"

if [[ -f "$QUEUE_ROOT/inbox/$TASK_ID.json" ]]; then
  mv "$QUEUE_ROOT/inbox/$TASK_ID.json" "$QUEUE_ROOT/claimed/$TASK_ID.json"
  echo "Claimed $TASK_ID"
else
  echo "Task not found in inbox: $TASK_ID" >&2
  exit 1
fi
