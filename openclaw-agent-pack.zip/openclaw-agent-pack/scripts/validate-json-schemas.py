#!/usr/bin/env python3
import json
from pathlib import Path

base = Path(__file__).resolve().parent.parent
examples = [
    base / "examples" / "task-example.json",
    base / "examples" / "result-example.json",
]
for p in examples:
    with p.open("r", encoding="utf-8") as f:
        json.load(f)
    print(f"OK: {p.name} parses as JSON")

print("Schema files are present. Use a JSON Schema validator in your target environment for full enforcement.")
