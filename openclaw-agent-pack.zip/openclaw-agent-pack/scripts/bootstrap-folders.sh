#!/usr/bin/env bash
set -euo pipefail

ROOT_FORGE="/srv/forgeorchestrate"
ROOT_AGENTS="/srv/openclaw/agents"

mkdir -p \
  "$ROOT_FORGE/queue/inbox" \
  "$ROOT_FORGE/queue/claimed" \
  "$ROOT_FORGE/queue/done" \
  "$ROOT_FORGE/queue/failed" \
  "$ROOT_FORGE/artifacts" \
  "$ROOT_FORGE/state/tasks" \
  "$ROOT_FORGE/state/reviews"

for agent in manager privacy-incident vendor-assessor research drafting; do
  mkdir -p \
    "$ROOT_AGENTS/$agent/workspace" \
    "$ROOT_AGENTS/$agent/state" \
    "$ROOT_AGENTS/$agent/logs" \
    "$ROOT_AGENTS/$agent/tmp"
done

echo "Created ForgeOrchestrate and agent folder structure."
