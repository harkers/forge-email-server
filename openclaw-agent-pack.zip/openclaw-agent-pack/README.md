# OpenClaw Multi-Agent Docker Workstream Pack

This pack provides a practical reference implementation for running multiple OpenClaw specialist agents with Docker-isolated execution, structured task handoff, and manager-led retrieval/review.

## Included

- `docs/architecture.md` — end-to-end architecture and design rationale
- `docs/implementation-plan.md` — phased rollout plan
- `docs/security-model.md` — trust boundaries, secrets, network posture, audit approach
- `config/openclaw.config.jsonc` — OpenClaw multi-agent config skeleton
- `config/docker-compose.yml` — starter compose topology
- `config/env.example` — environment variable template
- `schemas/task-packet.schema.json` — task contract schema
- `schemas/result-packet.schema.json` — result contract schema
- `examples/` — sample task/result packets and routing map
- `scripts/` — bootstrap and validation helpers

## Core design

- One OpenClaw gateway acts as the control plane
- Many native OpenClaw agents handle specialist workstreams
- Each specialist agent has:
  - its own workspace
  - its own state directory
  - its own Docker sandbox profile
  - its own tool/network policy
- A shared queue volume is used for deterministic handoff
- The manager agent owns routing, review, and final merge

## Recommended agent roles

- `manager`
- `privacy-incident`
- `vendor-assessor`
- `research`
- `drafting`

## Suggested host paths

- `/srv/forgeorchestrate/queue`
- `/srv/forgeorchestrate/artifacts`
- `/srv/forgeorchestrate/state`
- `/srv/openclaw/agents/<agent-id>/workspace`
- `/srv/openclaw/agents/<agent-id>/state`

## MVP principles

1. Keep one gateway
2. Do not share `agentDir`
3. Use files for task handoff first
4. Add Postgres later for metadata and analytics
5. Review every specialist output before publication or external action

## Hand-off model

The manager writes a packet to `/queue/inbox`. The assigned specialist claims the task, processes it in its sandbox, writes artifacts and a structured result packet, and the manager validates the result.

## Next implementation steps

1. Review and adapt `config/openclaw.config.jsonc`
2. Set host paths and secrets in `config/env.example`
3. Stand up the queue/artifact directory structure
4. Launch the compose stack
5. Test with `examples/task-example.json`
6. Add Postgres only after the queue-first flow is stable

